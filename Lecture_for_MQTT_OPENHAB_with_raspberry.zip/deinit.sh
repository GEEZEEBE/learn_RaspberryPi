sudo rm /etc/apt/sources.list.d/openhab.list
sudo apt-get --purge remove -y openhab-runtime openhab-addon-binding-mqtt openhab-addon-action-mail openhab-addon-binding-bluetooth openhab-addon-binding-serial openhab-addon-binding-weather openhab-addon-persistence-rrd4j
sudo rm -rf /home/pi/openHAB_Demo
sudo rm -rf /usr/share/openhab
sudo rm -rf /etc/openhab
sudo rm -rf /etc/apt/sources.list.d/mosquitto-jessie.*
sudo rm /home/pi/mosquitto-repo.gpg.key
sudo apt-get --purge remove -y mosquitto mosquitto-clients

