sudo cp openhab.list /etc/apt/sources.list.d/openhab.list
sudo apt-get update
sudo apt-get install --force-yes -y openhab-runtime openhab-addon-binding-mqtt openhab-addon-action-mail openhab-addon-binding-bluetooth openhab-addon-binding-serial openhab-addon-binding-weather openhab-addon-persistence-rrd4j
cd /home/pi/
mkdir openHAB_Demo
cd openHAB_Demo
wget https://github.com/openhab/openhab/releases/download/v1.6.2/distribution-1.6.2-demo-configuration.zip
unzip distribution-1.6.2-demo-configuration.zip
sudo cp -rf addons/ /usr/share/openhab/
sudo cp -rf configurations/ /etc/openhab/
cd /home/pi/Lecture_for_raspberry
sudo cp openhab.cfg /etc/openhab/configurations/
sudo cp kaizen.sitemap /etc/openhab/configurations/sitemaps
sudo cp kaizen.items /etc/openhab/configurations/items
cd /home/pi/
wget http://repo.mosquitto.org/debian/mosquitto-repo.gpg.key
sudo apt-key add mosquitto-repo.gpg.key
cd /etc/apt/sources.list.d/
sudo wget http://repo.mosquitto.org/debian/mosquitto-jessie.list
sudo apt-get update
sudo apt-cache search mosquitto
sudo apt-get install -y mosquitto mosquitto-clients
sudo /etc/init.d/mosquitto start
sudo /etc/init.d/openhab start
